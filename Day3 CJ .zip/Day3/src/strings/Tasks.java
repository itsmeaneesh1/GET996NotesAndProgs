package strings;

public class Tasks 
{
	
	String task3(String input)
	{
//WAP to get a string as input , change each consonants in the string to the next 
		//character and return.If Z/z is found change it to A/a respectively.
		//Sample : JAVA- KAWA	accent - addeou	  zampa	-> aanqa
		
		return input;
		
	}
	
	int task2(String input)
	{
		//WAP to get a string as input and find sum of digits and return it
		//Sample ;  ABC123	-> 6 	, a4b5c67	->22 , goa -> 0
		int sum=0;
		char ch[]=input.toCharArray();
		for(char c : ch)
		{
			if(Character.isDigit(c))
			{
			//	sum=sum+Character.getNumericValue(c);
				sum=sum+Integer.parseInt(Character.toString(c));
			}	
		}
		return sum;
	}

	int task1(String input)
	{
//WAP to get a string as input and find count of digits and return it
//Sample ;  ABC123	-> 3 	, a4b5c67	->4 , goa -> 0
		int count=0;
/*		char ch;
		for(int k=0;k<input.length();k++)
		{
			ch=input.charAt(k);
			if(Character.isDigit(ch))
				count++;
		} */
		char ch[]=input.toCharArray();
		for(char c : ch)
		{
			if(Character.isDigit(c))
				count++;
		}
	return count;	
	}
	
	public static void main(String[] args) 
	{
		System.out.println(new Tasks().task2("ABC1236"));
	}
}
