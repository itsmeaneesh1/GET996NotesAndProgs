package interfaces;
interface Bank
{
	int bankid=9001;
	int deposit();
	void withdraw();
}
interface Insurance
{
	void insureDeposit();
}
class HDFC implements Bank,Insurance
{
	@Override
	public int deposit() {
		return 0;
		
	}
	@Override
	public void withdraw() {
	}
	@Override
	public void insureDeposit() {
		
	}	
}
public class InterfaceDemo 
{
		public static void main(String[] args) {
			
			Bank obj=new HDFC();
			
		}
}
