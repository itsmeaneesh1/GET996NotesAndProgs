package abstractclass;

abstract class Mobile
{
	int imeno;
	abstract void setOs(); 
	void setOffers()
	{
		System.out.println("10% Offer");
	}
}
class SamsungMobiles extends Mobile
{
	@Override
	void setOs() {
		imeno=100;
		System.out.println("OS Set as Android");		
	}	
}
class Apple extends Mobile
{

	@Override
	void setOs() {
		// TODO Auto-generated method stub
		
	}	
}
public class ABSDemo 
{
	public static void main(String[] args) {
		
	}

}
