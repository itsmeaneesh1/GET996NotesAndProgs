package wrappers;

public class WrapDemos 
{
	public static void main(String[] args) 
	{
			char ch='A';
			Character c=new Character(ch);

			System.out.println(c.isDigit(ch));
			System.out.println(c.isLetter(ch));
			System.out.println(c.isUpperCase(ch));
			System.out.println(c.isLowerCase(ch));
		
			Double d=new Double(10.45);
			System.out.println(d.intValue());
			System.out.println(d.MAX_VALUE);
			
			String val="100";
			int num=Integer.parseInt(val);  // String to Integer
			System.out.println(num);
			
			String v2= String.valueOf(num); // Integer to String
			
			String v3= Integer.toString(num); //Integer to String
			
			
			
			
		/*	int num=100; //Primitive
			Integer i=new Integer(num); // Wrapper //Wrapping /Boxing
			
			System.out.println(i);
			System.out.println(i.floatValue());
			System.out.println(i.MAX_VALUE);
			System.out.println(i.MIN_VALUE);
			
			System.out.println(Integer.max(10, 20));
			System.out.println(Integer.min(5,9));
			
			num=i; //Unwrapping // UnBoxing ( Auto Unboxing)
			System.out.println(num);
			
			num=i.intValue(); // Unboxing
			System.out.println(num);
			
			*/
			
	}
}
