package com.lti.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyMvcController 
{

			@RequestMapping("/login")
			public ModelAndView showLogin()
			{
				ModelAndView mv=new ModelAndView("login");
				return mv;
			}
}

