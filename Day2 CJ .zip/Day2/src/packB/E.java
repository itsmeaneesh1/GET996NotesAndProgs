package packB;

import packA.D;

public class E {
	public static void main(String[] args) {
		D obj=new D();
		//obj.cool();
	}
}
