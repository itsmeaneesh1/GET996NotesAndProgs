package packB;

import packA.D;

public class F extends D
{
	public static void main(String[] args) {
		F obj=new F();
		obj.cool();
	}
}
