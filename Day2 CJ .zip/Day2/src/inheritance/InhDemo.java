package inheritance;
class Bank //Parent /Base /Super
{
	int bankid;
	void deposit() 
		{ System.out.println("Deposits"); }
	void withdraw() 
		{ System.out.println("Withdraws Money"); }
}
class ICICI extends Bank //Child / Derived / Subclass
{
	String ceoemail;
	void setInterest() 
	{ System.out.println("Interest Rate is 9.87");}
	
	void deposit() 
	{ System.out.println("Deposits in ICICI"); }
	
}
public class InhDemo
{
	public static void main(String[] args) 
	{
			ICICI chn1=new ICICI();
			chn1.deposit();
			chn1.withdraw();
			chn1.setInterest();
	}
}
