package staticdemos;

public class StatDemo 
{
		static int x; // Global ,Class variable
			//Shares across all the instances.		
		int y;//iNSTANCE		
		static void setValues()
		{
			x=100;
		//	y=200; //Can't access non static variables 
		}
		void setVals()
		{
			x=200;
			y=100;
		}		
		public static void main(String[] args) 
		{
			StatDemo s1=new StatDemo();
			StatDemo s2=new StatDemo();	
			StatDemo.setValues();
			s1.setVals();
			System.out.println(s1.x);
			System.out.println(s2.x);
			System.out.println(StatDemo.x);
			System.out.println(x);
		}
}
