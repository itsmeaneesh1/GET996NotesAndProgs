
public class Basic 
{
	
	int addnums(int x,int y) //formal
	{
		return y;
		
	}
	
public static void main(String[] args) 
{
	Basic b=new Basic();
	b.addnums(10, 20); //actual
}
}
