package construct;

public class Comment 
{
		Comment()
		{
			this("Java");	
			System.out.println("No comments");
		}
		Comment(String message)
		{
			this("C#","MS");
			System.out.println("Comment :"+message);
		}
		Comment(String message,String author)
		{
			System.out.println("Comment From "+author+" : "+message);
		}
		public static void main(String[] args)
		{
				Comment c1=new Comment();
			//	Comment c2=new Comment("Java Is Good");
			//	Comment c3=new Comment("Says So", "Ram");
		}
}
