package construct;
public class Product
{
		int price,qty,total;
		Product()
		{
			price=100;
			qty=3;
		}
		Product(int price , int qty)
		{
			this.price=price;
			this.qty=qty;
		}
		void findBill()
		{
			total=price*qty;
			System.out.println("Bill Amount is "+total);
		}
		public static void main(String[] args) {
				Product soap=new Product();
				soap.findBill();
				Product pen=new Product(20,5);
				pen.findBill();
		}
}
