package encapsulation;

public class Employee // VO (Value Obj) ,TO(Transfer Obj) ,Bean , POJO (Plain Old Java Obj) ,Entity
{
		private String psNo;
		private String firstName;
		private String jobTitle;
		static String desg;
		
		public String getPsNo() {
			return psNo;
		}
		public void setPsNo(String psNo) {
			this.psNo = psNo;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getJobTitle() {
			return jobTitle;
		}
		public void setJobTitle(String jobTitle) {
			this.jobTitle = jobTitle;
		}
		
		
		
}
