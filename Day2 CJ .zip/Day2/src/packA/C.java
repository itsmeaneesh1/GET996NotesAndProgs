package packA;

public class C {

	public static void main(String[] args) {
		D obj=new D();
		obj.cool();
	}
}
