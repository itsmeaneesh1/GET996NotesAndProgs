package packA;

public class D {
	
protected void cool()
 {
	 System.out.println("Access Cool");
 }
 public static void main(String[] args) {
		D obj=new D();
		obj.cool();
	}
 
}
