package arraysd;

import java.util.Scanner;

public class ArrayDemo {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String []fruits=new String[5];
		
		System.out.println("Enter Fruits");
		for(int x=0;x<fruits.length;x++)
		{
			fruits[x]=sc.next();
		}
		
		System.out.println("Fruits Are:");
		for(String f : fruits)
			System.out.println(f);
		
		/*
			int arr[];
			arr=new int[3];	
			arr[0]=100; arr[1]=200;arr[2]=300;
			
			int []arr2=new int[3];
			
			int arr3[]= {10,20,30};
			
			for(int x=0; x<arr.length ;x++)
				System.out.println(arr[x]);
			
			for(int x : arr3) //Foreach Loop
				System.out.println(x);		*/		
	}
//WAP to accept 5 fruit names from the user and display it.

}
