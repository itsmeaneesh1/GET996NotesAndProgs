package com.lti.hiber.pojo;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="CustomerKart")
public class CustomerKart {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int kartId;
	private LocalDate kartDate;
	private double kartTotal;
	
	//@OneToOne(mappedBy = "kart")
	//private Customer customer;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<CartItem> item;
	
	
	public int getKartId() {
		return kartId;
	}
	
	public List<CartItem> getItem() {
		return item;
	}
	public void setItem(List<CartItem> item) {
		this.item = item;
	}
	public void setKartId(int kartId) {
		this.kartId = kartId;
	}
	public LocalDate getKartDate() {
		return kartDate;
	}
	public void setKartDate(LocalDate kartDate) {
		this.kartDate = kartDate;
	}
	public double getKartTotal() {
		return kartTotal;
	}
	public void setKartTotal(double kartTotal) {
		this.kartTotal = kartTotal;
	}
	
	
	
}
