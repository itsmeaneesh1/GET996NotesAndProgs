package com.lti.hiber;

import com.lti.hiber.dao.MyDAO;

public class App 
{
    public static void main( String[] args )
    {
    		// Clone the HiberApp to HiberJPARelations
    		// empty the pojo and dao packages
    		// Clear the code from App.java excluding main
    	
    		MyDAO md=new MyDAO();
    		//md.OneToOneMap();
    		//md.OneToManyMap();
    		md.cartMapping();
    }
}
