package com.lti.hiber.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Customer123")
public class Customer 
{
		@Id
		@Column(name="customerid")
		private String custId;
		@Column(name="customername")
		private String custName;
		
		@OneToOne(cascade = CascadeType.ALL)	//One to One mapping
		@JoinColumn(name = "custAddress")
		private Address custAddress;

		@OneToOne(cascade = CascadeType.ALL ,fetch = FetchType.EAGER)
		@JoinColumn(name="custKart")
		private CustomerKart kart;
		
		public CustomerKart getKart() {
			return kart;
		}

		public void setKart(CustomerKart kart) {
			this.kart = kart;
		}

		public String getCustId() {
			return custId;
		}

		public void setCustId(String custId) {
			this.custId = custId;
		}

		public String getCustName() {
			return custName;
		}

		public void setCustName(String custName) {
			this.custName = custName;
		}

		public Address getCustAddress() {
			return custAddress;
		}

		public void setCustAddress(Address custAddress) {
			this.custAddress = custAddress;
		}
		
		
		
		
		
}
