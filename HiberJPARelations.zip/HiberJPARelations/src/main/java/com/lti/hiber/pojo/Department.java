package com.lti.hiber.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Department11")
public class Department 
{
		@Id
		private int deptno;
		private String deptName;
		
		@OneToMany(cascade = CascadeType.ALL)
		@JoinColumn(name="deptno")
		private List<Employee> employeeList;
		
		public Department(int deptno, String deptName) {
			super();
			this.deptno = deptno;
			this.deptName = deptName;
		}
		public Department() {
			super();
		}
		public int getDeptno() {
			return deptno;
		}

		public void setDeptno(int deptno) {
			this.deptno = deptno;
		}

		public String getDeptName() {
			return deptName;
		}

		public void setDeptName(String deptName) {
			this.deptName = deptName;
		}

		public List<Employee> getEmployeeList() {
			return employeeList;
		}

		public void setEmployeeList(List<Employee> employeeList) {
			this.employeeList = employeeList;
		}
		
		
}
