package com.lti.hiber.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="CustomerAddress")
public class Address
{
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name="custAddId")
		private int addId;
		@Column(name="custHouseName")
		private String houseName;
		@Column(name="custStreet")
		private String street;
		@Column(name="custCity")
		private String city;
		//Bi Directional Mapping
		@OneToOne(mappedBy = "custAddress")
		private Customer customer;
		
		
		
		public int getAddId() {
			return addId;
		}
		public void setAddId(int addId) {
			this.addId = addId;
		}
		public String getHouseName() {
			return houseName;
		}
		public void setHouseName(String houseName) {
			this.houseName = houseName;
		}
		public String getStreet() {
			return street;
		}
		public void setStreet(String street) {
			this.street = street;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		
		
		
		
}
