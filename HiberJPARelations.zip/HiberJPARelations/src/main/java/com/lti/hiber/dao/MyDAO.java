package com.lti.hiber.dao;

import java.time.LocalDate;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.hiber.pojo.Address;
import com.lti.hiber.pojo.CartItem;
import com.lti.hiber.pojo.Customer;
import com.lti.hiber.pojo.CustomerKart;
import com.lti.hiber.pojo.Department;
import com.lti.hiber.pojo.Employee;

public class MyDAO 
{
		public void cartMapping()
		{
				CartItem item1=new CartItem("P001","Wheat", 100);
				CartItem item2=new CartItem("P002","Bread", 40);
				CartItem item3=new CartItem("P003","Pen", 10);
				
				List<CartItem> items=new ArrayList<CartItem>();
				items.add(item1) ; items.add(item2); items.add(item3);
				
				CustomerKart ck=new CustomerKart();
				ck.setKartDate(LocalDate.now());
				ck.setKartTotal(1000);
				ck.setItem(items);
				
				Customer cc=new Customer();
				cc.setCustId("C001");
				cc.setCustName("Yash");
				cc.setKart(ck);
				
				EntityManagerFactory eManFac=new Persistence().createEntityManagerFactory("MyDB");
				EntityManager eMan= eManFac.createEntityManager();			
				eMan.getTransaction().begin();
					eMan.persist(ck);
					eMan.persist(cc);
				eMan.getTransaction().commit();			
				System.out.println("Records Saved..");
				eMan.close();
				eManFac.close();
				
				
		}
	
	
		public void OneToManyMap()
		{
				Employee e1=new Employee("E001","Kajal", 23000);
				Employee e2=new Employee("E002","Raghu",18990);
				Employee e3=new Employee("E003","Ram", 21000);
				Employee e4=new Employee("E004","Dev", 21300);
				
				List<Employee> dep10=new ArrayList<Employee>();
				dep10.add(e1);   dep10.add(e2);
				List<Employee> dep20=new ArrayList<Employee>();
				dep20.add(e3);   dep20.add(e4);
				
				Department d10=new Department(10, "IT");
				d10.setEmployeeList(dep10);				
				Department d20=new Department(20, "Sales");
				d20.setEmployeeList(dep20);
				
				EntityManagerFactory eManFac=new Persistence().createEntityManagerFactory("MyDB");
				EntityManager eMan= eManFac.createEntityManager();			
				eMan.getTransaction().begin();
					eMan.persist(d10);
					eMan.persist(d20);				
				eMan.getTransaction().commit();			
				System.out.println("Records Saved..");
				eMan.close();
				eManFac.close();
				
		}
	
	
	
		public void OneToOneMap()
		{
				Address address=new Address();
				address.setHouseName("Neehara");
				address.setStreet("14thCross");
				address.setCity("Kollam");
				
				CustomerKart kart=new CustomerKart();
				kart.setKartDate(LocalDate.now());
				kart.setKartTotal(1000); 
				
				Customer cust=new Customer();
				cust.setCustId("C001");
				cust.setCustName("Raghav");
				cust.setCustAddress(address);
				cust.setKart(kart); //new
				
				EntityManagerFactory eManFac=new Persistence()
						.createEntityManagerFactory("MyDB");
				EntityManager eMan= eManFac.createEntityManager();			
				eMan.getTransaction().begin();
				
					eMan.persist(cust);
					
				eMan.getTransaction().commit();			
				System.out.println("Customer Saved..");
				eMan.close();
				eManFac.close();
				
		}
}
