package com.lti.hiber.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee11")
public class Employee
{
	@Id
	@Column(name="employeeno")
	private String empno;
	@Column(name="employeename")
	private String empName;
	private double salary;
	
	public Employee() {
		super();
	}
	public Employee(String empno, String empName, double salary) {
		super();
		this.empno = empno;
		this.empName = empName;
		this.salary = salary;
	}
	public String getEmpno() {
		return empno;
	}
	public void setEmpno(String empno) {
		this.empno = empno;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}

	
	
	
}
