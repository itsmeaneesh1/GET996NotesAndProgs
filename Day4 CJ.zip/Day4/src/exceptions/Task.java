package exceptions;
class InvalidCardException extends Exception
{
	 InvalidCardException(String message)
	 {
		 super(message);
	 }
}
class VerifyCard
{
	void verifyCard(String cardNo) throws InvalidCardException
	{
			if(cardNo.length()!=10)
				throw new InvalidCardException("Invalid Length");
			else if(verifyDigits(cardNo)==false)
				throw new InvalidCardException("Invalid CardNo");
			System.out.println("Card Verified");
//WAP to verify the cardNo passed as argument .
	//Verify CardNo is of length 10 and all are digits.
	//If cardNo is not 10 raise InvalidCardException with message "Invalid Length"
	//If cardNo is having anything apart from digits raise InvalidCardException with message "Invalid CardNo"
		//If valid , display " Card Verfied" . 
	}
	boolean verifyDigits(String input)
	{
		boolean res=true;
		char ch[]=input.toCharArray();
		for(char c :ch)
		{
			if(!(Character.isDigit(c)))
			{
				res=false;
				break;
			}
		}
		return res;
	}
}
public class Task 
{
		public static void main(String[] args) 
		{
				VerifyCard vc=new VerifyCard();
				try {
					vc.verifyCard("123456789A");
				} catch (InvalidCardException e) {
					System.out.println(e.getMessage());
				}
		}
}
