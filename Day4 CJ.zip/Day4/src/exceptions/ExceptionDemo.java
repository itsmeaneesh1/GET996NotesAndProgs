package exceptions;

import java.io.FileInputStream;

public class ExceptionDemo 
{
public static void main(String[] args) 
{
	
		int arr[]= {10,20,5,0};	
		int result=0;
		try
		{
		result=arr[1] / arr[2];
			try {
				int sum=Integer.parseInt("abc");
				}
			catch (Exception e) {
				System.out.println("Error");
			}			
		}
		catch (ArithmeticException e) 
		{
			System.out.println("Error "+ e.getMessage());
		}
		catch (ArrayIndexOutOfBoundsException e) 
		{
			System.out.println("Array Access Error @"+ e.getMessage());
		}
		catch (Exception e) {
			System.out.println("Main Errors");
		}
		finally
		{
		System.out.println("Result is :"+result);
		}
}
}
