package exceptions;
class InvalidAgeException extends Exception
{
	InvalidAgeException(String message)
	{    super(message); }
}
class VerifyAge
{
	void getAge(int age) throws InvalidAgeException
	{
		if(age<18)
			throw new InvalidAgeException("Invalid Age!!");
		System.out.println("Age Verified");
	}
}
public class UserExceptionDemo 
{
	public static void main(String[] args)
	{
			VerifyAge obj=new VerifyAge();
			try {
				obj.getAge(12);
			} catch (InvalidAgeException e) {
				System.out.println(e.getMessage());
			}
	}
}
