package exceptions;

import java.awt.FileDialog;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ThrowsDemo
{
		void callFiles() throws FileNotFoundException
		{
				FileInputStream fst=new FileInputStream("C:\\Sparta.txt");
		}
		public static void main(String[] args) 
		{
				try {
					new ThrowsDemo().callFiles();
				} catch (FileNotFoundException e) {
					System.out.println("Invalid file Name");
				}
		}
}
