package tasks;

public class Tasks {
		int task1(int nums[])
		{
			return 0;
			//WAP to accept an array of integers, 
			//remove the duplicates and find the sum and return
		}
		String task2(String input)
		{
			return null;
			//WAP to get a string ,remove the duplicate characters ,sort the letters
			//in ascending and return as a string
			// sample :  malayalam 		- > almy
		}
		String task3()
		{
			return null;
			//WAP to accept a String, remove the duplicate characters,and return the 
			//string  , sample :  malayalam 		- > maly
		}
		public static void main(String[] args)
		{
			int input[]= {1,2,3,1,3,4,9,1,2,4,1,3,6};
			Tasks obj=new Tasks();
			System.out.println(obj.task1(input));
			System.out.println(obj.task2("malayalam"));
			System.out.println(obj.task2("maly"));
			
		}
}
