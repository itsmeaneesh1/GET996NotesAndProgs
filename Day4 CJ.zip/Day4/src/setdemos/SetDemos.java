package setdemos;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemos 
{
public static void main(String[] args)
{
		//Set<String> obj=new HashSet<String>();
	
	//	Set<String> obj=new TreeSet<String>();
	
	Set<String> obj=new TreeSet<String>().descendingSet();
			obj.add("Hanna");
			obj.add("Jack");		
			obj.add("Arul");
			obj.add("Devak");
			System.out.println(obj);
			
			Set<Integer> nums=new  	TreeSet<Integer>();	
			nums.add(90);
			nums.add(45);
			System.out.println(nums);
}
}
