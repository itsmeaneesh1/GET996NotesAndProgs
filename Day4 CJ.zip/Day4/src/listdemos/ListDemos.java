package listdemos;

import java.util.ArrayList;
import java.util.List;

public class ListDemos 
{
public static void main(String[] args) 
{
	List obj=new ArrayList();
	
	obj.add(10);
	obj.add(10);
	obj.add(10);
	obj.add(10);
	obj.add(40);
	obj.add(50);	
			System.out.println(obj);
			System.out.println(obj.indexOf(10));
			System.out.println(obj.lastIndexOf(10));
			obj.remove(4);
			System.out.println(obj);
			obj.set(2, 999);
			System.out.println(obj);
						
			/*
			 * List obj=new ArrayList(); //RAW
			obj.add(100);
			obj.add(200);
			obj.add(0,300);	
			List obj2=new ArrayList();
			obj2.addAll(obj);
			System.out.println(obj2);
			obj2.addAll(1, obj);
			System.out.println(obj2);
			//obj2.clear();		
			System.out.println(obj.contains(100));
			System.out.println(obj);
			System.out.println(obj.get(0));
			for(int k=0;k<obj.size();k++)
			{
				System.out.println(obj.get(k));
			}*/
}
}
