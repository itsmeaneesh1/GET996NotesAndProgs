package listdemos;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class task 
{
		void problem1(String names[])
		{
	//WAP to store the names array elements in an ArrayList. Make all names to CAPS.
		List arr=new ArrayList();		 
		 for(String s :names)
		 {
			 arr.add(s.toUpperCase());
		 }
		 System.out.println(arr);
		}
		void problem2(String input)
		{
		//WAP to get a String with names separated by comma, Store the names in ArrayList.
			List arr=new ArrayList();	
			
		//	StringTokenizer stz=new StringTokenizer(input, ",");
		//		while(stz.hasMoreTokens())
		//			arr.add(stz.nextToken());
			
			
			String s[]=input.split(",");
			for(String s1:s)
				arr.add(s1);
			
			System.out.println(arr);
		}
		
		public static void main(String[] args) 
		{
				String names[]= {"apple","samsung","oppo","vivo"};
				new task().problem1(names);
				String inp="apple,orage,banana,grape,lemon";
				new task().problem2(inp);
			
		}
}
