package generics;

import java.util.*;

public class GenericsDemo 
{
public static void main(String[] args) 
{
			List<Integer> numbers=new ArrayList<Integer>();
			numbers.add(10);
			numbers.add(20);
			numbers.add(30);
			//numbers.add(null);
			//numbers.add("dd"); Error
			int sum=0;
			for(int num : numbers)
			{
					sum= sum+num;
			}
			
			
			System.out.println(sum);
			
}
}
