package iteration;

import java.util.*;
public class IterMethods 
{
public static void main(String[] args)
{
		List<String> names=new ArrayList<String>();
		names.add("Arpit"); names.add("Pavani") ;names.add("Shreya");
		//FOR LOOP -> Works with LIST
		for(int x=0;x<names.size();x++)
			System.out.println(names.get(x));
		//FOREACH -> Works with LIST and SET
		for(String  s:names)
			System.out.println(s);
		//ITERATOR -> Works with LIST and SET
			Iterator<String> itr=names.iterator();
			while(itr.hasNext())
					System.out.println(itr.next());
		//LIST ITERATOR -> Works with LIST
			ListIterator<String> itr2=names.listIterator();
			while(itr2.hasNext())
				System.out.println(itr2.next());
			while(itr2.hasPrevious())
				System.out.println(itr2.previous());
}	
}
