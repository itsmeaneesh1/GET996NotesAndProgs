package com.lti.hiber.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student123")
public class Student 
{
	@Id
	private int studentId;
	private String stduentName;
	private String gender;
		
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", stduentName=" + stduentName + ", gender=" + gender + "]";
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int studentId, String stduentName, String gender) {
		super();
		this.studentId = studentId;
		this.stduentName = stduentName;
		this.gender = gender;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStduentName() {
		return stduentName;
	}
	public void setStduentName(String stduentName) {
		this.stduentName = stduentName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	/*
	 * Create a pojo named Student with fields studentId (int) ,studentName and gender
	 * Create a pojo named Course with fields courseId (String),courseName,duration (int)
	 * Make One to Many mapping between Course and Students.
	 * Add some data and persist the records.
	 * Use hbm2ddlauto to create for first run and disable it after.
	 */
}
