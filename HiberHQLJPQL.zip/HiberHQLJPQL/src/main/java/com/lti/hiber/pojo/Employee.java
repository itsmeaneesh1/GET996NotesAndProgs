package com.lti.hiber.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="emp80")
@NamedQueries(
		{
			@NamedQuery(name ="getAllEmps",query = "from Employee"),
			@NamedQuery(name="filterSalary",query = "from Employee e where e.salary between ?1 and ?2"),
			@NamedQuery(name="sortByfname",query = "from Employee e order by e.firstName")
		}
		)
public class Employee 
{
		@Id
		@Column(name="empno")
		private int empno;
		@Column(name="fname")
		private String firstName;
		@Column(name="lname")
		private String lastName;		
		private int salary;
			
		@Override
		public String toString() {
			return "Employee [empno=" + empno + ", firstName=" + firstName + ", lastName=" + lastName + ", salary="
					+ salary + "]";
		}
		public int getEmpno() {
			return empno;
		}
		public void setEmpno(int empno) {
			this.empno = empno;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
		
		
		
}
