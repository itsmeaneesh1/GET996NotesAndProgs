package com.lti.hiber;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.hiber.pojo.Course;
import com.lti.hiber.pojo.Employee;
import com.lti.hiber.pojo.Student;

public class App 
{
    public static void main( String[] args )
    {
    	//JOINS in JPQL
    	EntityManagerFactory eManFac=new Persistence().createEntityManagerFactory("MyDB");
		EntityManager eMan= eManFac.createEntityManager();
    	
		Query qry2=eMan.createQuery("select  c from Course c LEFT JOIN c.studList s");
    	List<Course> studs=qry2.getResultList();
    	
    	for(Course s : studs)
    		System.out.println(s);
    	
    	Query qry=eMan.createQuery("select  s from Course c RIGHT JOIN c.studList s");
    	List<Student> studs2=qry.getResultList();
    	
    	for(Student s : studs2)
    		System.out.println(s);
    	
    	eMan.close();
		eManFac.close(); 
		
		/*
    	Query qry=eMan.createQuery("from Course c");
    	List<Course> courses=qry.getResultList();
    	
    	for(Course c: courses)
    		System.out.println(c);
    		
    	Query qry2=eMan.createQuery("select c.studList from Course c");
    	List<Student> studs=qry2.getResultList();
    	
    	for(Student s : studs)
    		System.out.println(s);
    	
		
		
    	
    	Student s1=new Student(1001, "Jack", "Male");
    	Student s2=new Student(1002, "Radha", "Female");
    	
    	List<Student> ss=new ArrayList<Student>();
    			ss.add(s1) ; ss.add(s2);
    	
    	Course java=new Course(201, "Java", 180);		
    	java.setStudList(ss);
    	
    	EntityManagerFactory eManFac=new Persistence().createEntityManagerFactory("MyDB");
		EntityManager eMan= eManFac.createEntityManager();
		
		eMan.getTransaction().begin();
		eMan.persist(java);
		eMan.getTransaction().commit();
		
		System.out.println("Course Added with Students..");
		eMan.close();
		eManFac.close();
	
		Query q1=eMan.createNamedQuery("getAllEmps");
		List<Employee> empList=q1.getResultList();		
		for(Employee e : empList)
			System.out.println(e);
		
		Query q2=eMan.createNamedQuery("filterSalary");
		q2.setParameter(1, 10000); 
		q2.setParameter(2, 20000);
		List<Employee> empList2=q2.getResultList();		
		for(Employee e : empList2)
			System.out.println(e);
		
		Query q3=eMan.createNamedQuery("sortByfname");
		List<Employee> empList3=q3.getResultList();		
		for(Employee e : empList3)
			System.out.println(e);
		//Passing arguments dynamically
		//POSITIONAL PARAMETERS 
	
		Query qry=eMan.createQuery("from Employee e where e.salary between ?1 and ?2");
		qry.setParameter(1,15000);
		qry.setParameter(2, 20000);
		
		List<Employee> empList=qry.getResultList();		
				for(Employee e : empList)
						System.out.println(e);
				
		//NAMED PARAMETERS
		Query qry2=eMan.createQuery("from Employee e where e.salary between :lowsal and :upsal");
		qry2.setParameter("lowsal",15000);
		qry2.setParameter("upsal", 20000);		
		
		List<Employee> empList2=qry2.getResultList();		
		for(Employee e : empList2)
				System.out.println(e);*/
		
		//WAP to accept character from the user and display the employees whose first name starts with that letter.
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the First Letter");
		String fLet=sc.next();
		
		Query qry2=eMan.createQuery("from Employee e where e.firstName LIKE :patt");
		qry2.setParameter("patt",fLet+"%");
			
		List<Employee> empList2=qry2.getResultList();		
		for(Employee e : empList2)
				System.out.println(e);
		
		*/
	//	Query qry=eMan.createQuery("select max(e.salary) from Employee e");
	//	int maxsal=(int) qry.getSingleResult();
	//	System.out.println("Max Salary is "+maxsal);
		 
	//	Query qry=eMan.createQuery("select salary from Employee e where e.empno=150");
	//	int sal=(int) qry.getSingleResult();
	//	System.out.println("EmpNo 150's Salary is "+sal);
		
		
		
		//Query qry=eMan.createQuery("from Employee");
		//qry.setFirstResult(0);
		//qry.setMaxResults(5);
		
		//Query qry=eMan.createQuery("select e from Employee e");
		//Query qry=eMan.createQuery("from Employee e where e.salary>20000");
		//Query qry=eMan.createQuery("from Employee e where e.salary between 15000 and 20000");
		//List<Employee> empList=qry.getResultList();
		
		//for(Employee e : empList)
				//System.out.println(e);
		
		
		
		//eMan.close();
		//eManFac.close();
    }
}
